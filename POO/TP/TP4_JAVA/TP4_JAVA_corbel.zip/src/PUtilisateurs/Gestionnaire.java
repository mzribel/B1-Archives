package PUtilisateurs;

public class Gestionnaire extends Utilisateur{
    public Gestionnaire(String firstName, String lastName, String adresseRue,String adresseVille,
                    String adresseCP,String email) {
        super(firstName, lastName, adresseRue, adresseVille, adresseCP, email);
    }
}
